import React from 'react';
import { Text, TouchableOpacity, View } from 'react-native-web';

// import default button styles
import styller from 'components/styller';
import styles from 'assets/styles/buttons';

export default styller(styles)(TouchableOpacity);
