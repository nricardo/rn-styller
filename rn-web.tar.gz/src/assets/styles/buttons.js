import { StyleSheet } from 'react-native-web';

/**
 * Buttons
 * --------------------------------------------------------------------------
 */
const DEFAULTS = {
  bgColor: '#777',
  radius: 20,
  type: 'primary',
};

const getBtnBgColor = (type) => {
  switch (type) {
    case 'primary':
      return '#3185f1';
    case 'secondary':
    case 'info':
    case 'danger':
    case 'warning':
    default:
      return DEFAULTS.bgColor;
  }
};

const _Button = (props) => {
  const { type, radius } = Object.assign({}, DEFAULTS, props);

  return {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: getBtnBgColor(type),
    borderRadius: radius,
    margin: 10,
    padding: 10,
    // height: 30,
    // minWidth: 110,
  };
};

export default (props) => StyleSheet.create({
  Button: _Button(props),
});
