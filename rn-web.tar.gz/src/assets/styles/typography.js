import { StyleSheet } from 'react-native-web';
import SHARED from 'assets/styles/common';

/**
 * Typography
 * --------------------------------------------------------------------------
 */
const DEFAULTS = {
  color: 'midnightblue',
  size: 16,
  bold: false,
  decoration: 'none',
};

const _Text = (props) => {
  const { color, size, bold, decoration } = Object.assign({}, DEFAULTS, props);

  return {
    // inject shared styles
    ...SHARED(props),

    // define base styles for this component
    color,
    fontFamily: 'Roboto',
    fontSize: size,
    fontWeight: bold ? 'bold' : 'normal',
    textDecorationLine: decoration,
  };
};

const _Heading = (props) => {
  props = Object.assign({}, {
    bold: true,
    size: 24,
  }, props);
  return _Text(props);
};

export default (props) => StyleSheet.create({
  Text: _Text(props),
  Heading: _Heading(props),
});
