import React, { Component } from 'react';
import { Image } from 'react-native-web';

import { Box, Button, Counter, Heading, Text } from './components';

export default class App extends Component {

  onChange(field, value) {
    this.setState({ [field]: value });
  }

  componentWillMount() {
    this.logo = <Image
      // resizeMode="cover"
      source={{
        uri: 'http://via.placeholder.com/50x50',
        height: 50, width: 50,
      }} />;
  }

  render() {
    return (
      <Box full="true" p={20}>

        <Box row="true" center="true" m={20} border="red">
          <Heading size={48}>Welcome to Styller</Heading>
        </Box>

        <Box full="true" border="green">
          <Heading mb={10} decoration="underline">Typography</Heading>
          <Text>Normal Text</Text>
          <Text bold="true">This text is bold!</Text>
          <Text color="pink">Text in Pink!!</Text>

          <Button><Text color="white">Basic button</Text></Button>
        </Box>


        {/* <Counter target={this.state.count} total={1024} color="red" size={75} /> */}

      </Box>
    );
  }
}
